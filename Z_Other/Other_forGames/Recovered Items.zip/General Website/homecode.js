function home(){

document.getElementById("homePage").style.display = "block";
document.getElementById("aboutPage").style.display = "none";
document.getElementById("playPage").style.display = "none";
document.getElementById("makePage").style.display = "none";
document.getElementById("highscore").style.display = "none";

}/*
var x = document.getElementById("geo");
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    x.innerHTML = "Geolocation is not supported by this browser.";
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude;
}*/
function about(){

document.getElementById("homePage").style.display = "none";
document.getElementById("aboutPage").style.display = "block";
document.getElementById("playPage").style.display = "none";
document.getElementById("makePage").style.display = "none";
document.getElementById("highscore").style.display = "none";

}
function play(){

document.getElementById("homePage").style.display = "none";
document.getElementById("aboutPage").style.display = "none";
document.getElementById("playPage").style.display = "block";
document.getElementById("makePage").style.display = "none";
document.getElementById("highscore").style.display = "none";

}
function make(){

document.getElementById("homePage").style.display = "none";
document.getElementById("aboutPage").style.display = "none";
document.getElementById("playPage").style.display = "none";
document.getElementById("makePage").style.display = "block";
document.getElementById("highscore").style.display = "none";

}
function high(){

document.getElementById("homePage").style.display = "none";
document.getElementById("aboutPage").style.display = "none";
document.getElementById("playPage").style.display = "none";
document.getElementById("makePage").style.display = "none";
document.getElementById("highscore").style.display = "block";

loadHighScores();
}

function loadHighScores(){
	
	var x = localStorage.getItem("highscore7");
	if (x=="undefined"){
		x ==0;	
	}
	document.getElementById("ImpH").innerHTML = x;
	
	document.getElementById("EhardH").innerHTML = localStorage.getItem("highscore5");
	document.getElementById("VhardH").innerHTML = localStorage.getItem("highscore4");
	document.getElementById("HardH").innerHTML = localStorage.getItem("highscore3");
	document.getElementById("medH").innerHTML = localStorage.getItem("highscore2");
	document.getElementById("easyH").innerHTML = localStorage.getItem("highscore1");
	document.getElementById("begH").innerHTML = localStorage.getItem("highscore0");

	document.getElementById("EhardHn").innerHTML = localStorage.getItem("HSname5");
	document.getElementById("VhardHn").innerHTML = localStorage.getItem("HSname4");
	document.getElementById("hardHn").innerHTML = localStorage.getItem("HSname3");
	document.getElementById("medHn").innerHTML = localStorage.getItem("HSname2");
	document.getElementById("easyHn").innerHTML = localStorage.getItem("HSname1");
	document.getElementById("begHn").innerHTML = localStorage.getItem("HSname0");	
 	
	
}

// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}